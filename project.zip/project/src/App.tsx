import React, { useState } from 'react';
import { SubjectSelector } from './components/SubjectSelector';
import { ChapterSelector } from './components/ChapterSelector';
import { ChapterContent } from './components/ChapterContent';
import { subjectsData } from './data/subjects';

function App() {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);

  const handleReset = () => {
    setSelectedChapter(null);
    setSelectedSubject(null);
  };

  if (!selectedSubject) {
    return (
      <SubjectSelector
        subjects={Object.keys(subjectsData)}
        selectedSubject={selectedSubject}
        onSelect={setSelectedSubject}
      />
    );
  }

  if (!selectedChapter) {
    return (
      <ChapterSelector
        chapters={Object.keys(subjectsData[selectedSubject])}
        selectedChapter={selectedChapter}
        onSelect={setSelectedChapter}
        onBack={handleReset}
      />
    );
  }

  return (
    <ChapterContent
      chapters={subjectsData[selectedSubject][selectedChapter]}
      onBack={() => setSelectedChapter(null)}
    />
  );
}

export default App;